#include <tunables/global>

/popush/bin/jre/bin/java {
  #include <abstractions/base>
  /popush/bin/jre/lib/** mr,
  /popush/tmp/** r,
}