#include <tunables/global>

/popush/bin/lua {
  #include <abstractions/base>
  /popush/tmp/** r,
}
